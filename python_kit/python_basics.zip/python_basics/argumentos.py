'''
 Argumentos

 Se tiene que importar la libreria sys.
 La lista sys.argv contiene los argumentos que ha pasado el usuario al programa.
 Por ejemplo, sys.argv[1] seria el primer argumento.
 Con len(sys.argv) podemos saber cuantos argumentos nos pasaron.
'''
